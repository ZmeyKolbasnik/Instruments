File Type:		SoundFont
Bank name:		HardRockDrums.sf2
File Format:		SF2
Machine:		SoundBlaster AWE64 / Live! and compatible soundcards
Memory required:	min. 16Mb
Archive:		sfPack (available on www.megota.com)
Cathegory:		Drumkit
Copyright:		freely distributable
Date:			08/04/2000
Author:			Guido Scognamiglio - ziokiller@lycosmail.com

Home Page:		http://listen.to/ums

This SoundFonts can only be shared in its original ZIP archive.