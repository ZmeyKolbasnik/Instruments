File Type:		SoundFont
Bank name:		GoldDrums.sf2
File Format:		SF2
Machine:		SoundBlaster Live! and compatible soundcards
Memory required:	min. 16Mb
Archive:		sfPack (available on www.megota.com)
Categhory:		Drumkit
Copyright:		freely distributable
Date:			11/04/2000
Author:			Guido Scognamiglio - info@soundfonts.it	
Home Page:		http://www.soundfonts.it
			
This SoundFonts can only be shared in its original ZIP archive.

!!! DO NEVER PAY FOR ANY SOUNDFONTS ON THE NET !!!