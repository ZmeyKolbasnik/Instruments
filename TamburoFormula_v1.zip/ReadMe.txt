Tamburo Formula Soundfont, development version.

This soundfont was created with samples taken from a Tamburo "Formula" drumset, recorded 
in a isolated drumbox on November 2001. Session drummer: Mario Borrelli.

All the samples are original except for the hihat samples, taken temporarly from another drumset.
During the recording session we forgot to sample the open and pedal hihats :-)
so I decided to replace them with a complete set of hihat taken from another soundfont....

In the next session we will complete it with newer cymbals :-)

All samples are stereo, 44.1KHz 16bit, not processed at all. 
All single instruments are multilayered except for the splash cymbal.

Free for any use.
No money charge is permitted.

Author: Guido Scognamiglio
Up Metal! Studio
http://www.soundfonts.it
info@soundfonts.it

Enjoy!