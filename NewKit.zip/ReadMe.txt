File Type:		SoundFont
Bank name:		NewKit.sf2
File Format:		SF2
Machine:		SoundBlaster AWE64 / Live! and compatible soundcards
Memory required:	min. 16Mb
Archive:		sfPack (available on www.megota.com)
Categhory:		Drumkit
Copyright:		freely distributable
Date:			25/07/2000
Author:			Guido Scognamiglio - ziokiller@lycosmail.com
			

Home Page:		Guido Scognamiglio - http://listen.to/ums
			

This SoundFonts can only be shared in its original ZIP archive.