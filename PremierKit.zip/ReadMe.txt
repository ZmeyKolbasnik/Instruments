File Type:		SoundFont
Bank name:		PremierKit.sf2
File Format:		SF2
Machine:		SoundBlaster Live! and compatible soundcards
Memory required:	min. 16Mb
Archive:		sfPack (available on www.megota.com)
Categhory:		Drumkit
Copyright:		freely distributable
Date:			01/29/2001
Author:			Guido Scognamiglio - info@soundfonts.it	
Home Page:		http://www.soundfonts.it
			
This SoundFonts can only be shared in its original ZIP archive.