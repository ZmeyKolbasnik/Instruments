File Type:		SoundFont
Bank Name:		HammondC3.sf2
File Format:		SF2
Machine:		SoundBlaster AWE64 / Live! and compatible soundcards
Required memory:	min. 4Mb
Archive:		sfArk (available on www.melodymachine.com)
Categhory:		Organ
Copyright:		freely distributable
Date:			02/06/2001
Author:			Guido Scognamiglio
E-Mail:			info@soundfonts.it
Home Page:		http://www.soundfonts.it

This SoundFonts can only be shared in its original ZIP archive.