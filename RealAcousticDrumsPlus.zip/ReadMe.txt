File Type:		SoundFont
Bank name:		RealAcousticDrumsPlus.sf2
File Format:		SF2
Machine:		SoundBlaster AWE64 / Live! and compatible soundcards
Memory required:	min. 4Mb
Archive:		sfArk (available on www.melodymachine.com)
Categhory:		Drumkit
Copyright:		freely distributable
Date:			18/04/1999
Authors:		Guido Scognamiglio - ziokiller@lycosmail.com
			Alessandro Ruiu - aruiu@nuoro.net
			SoundWare - soundware@xoommail.com

Home Pages:		Guido Scognamiglio - http://listen.to/ums
			Alessandro Ruiu - http://www.ssnet.it/utenti/aruiu
			SoundWare - http://listen.to/soundware


Thanx to eLLeGi (www.ellegi.net) from www.net1is.it

This SoundFonts can only be shared in its original ZIP archive.