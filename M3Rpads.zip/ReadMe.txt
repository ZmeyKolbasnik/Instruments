File Type:		SoundFont
Bank name:		M3R Pads.sf2
File Format:		SF2
Machine:		SoundBlaster AWE64 / Live! and compatible soundcards
Memory required:	min. 4Mb
Archive:		sfArk (available on www.melodymachine.com)
Categhory:		Pads
Copyright:		freely distributable
Date:			january 1999
Author:			Guido Scognamiglio
E-Mail:			ziokiller@lycosmail.com
Home Page:		http://listen.to/ums
Thanx to eLLeGi (www.ellegi.net) from www.net1is.it

This SoundFonts can only be shared in its original ZIP archive.