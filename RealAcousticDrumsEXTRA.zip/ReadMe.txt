File Type:		SoundFont
Bank name:		RealAcousticDrumsEXTRA.sf2
File Format:		SF2
Machine:		SoundBlaster AWE64 / Live! and compatible soundcards
Memory required:	min. 8Mb
Archive:		sfPack (available on www.megota.com)
Categhory:		Drumkit
Copyright:		freely distributable
Date:			09/07/1999
Author:			Guido Scognamiglio - ziokiller@lycosmail.com
			

Home Page:		Guido Scognamiglio - http://listen.to/ums
			

Thanx to eLLeGi (www.ellegi.net) from www.net1is.it

This SoundFonts can only be shared in its original ZIP archive.